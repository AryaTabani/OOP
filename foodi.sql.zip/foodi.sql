-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jul 15, 2023 at 08:37 AM
-- Server version: 5.7.36
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `foodi`
--

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
CREATE TABLE IF NOT EXISTS `comment` (
  `Comm` varchar(500) NOT NULL,
  `response` varchar(500) NOT NULL,
  `Food` varchar(250) NOT NULL,
  `Score` int(100) DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`Comm`, `response`, `Food`, `Score`) VALUES
('Nice', '', 'Naugatmoose', 5);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
CREATE TABLE IF NOT EXISTS `customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(100) NOT NULL,
  `prod_id` varchar(100) NOT NULL,
  `prod_name` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `quantity` int(100) NOT NULL,
  `price` double NOT NULL,
  `date` date DEFAULT NULL,
  `image` varchar(500) NOT NULL,
  `em_username` varchar(100) DEFAULT NULL,
  `Customername` varchar(500) NOT NULL,
  `IsDelivered` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `customer_id`, `prod_id`, `prod_name`, `type`, `quantity`, `price`, `date`, `image`, `em_username`, `Customername`, `IsDelivered`) VALUES
(4, 2, '8', 'Naugatmoose', 'Drinks', 2, 6, '2023-07-15', 'C:\\\\\\\\Users\\\\\\\\Asus\\\\\\\\Downloads\\\\\\\\images\\\\\\\\naugatmoose.jpg', 'FarzadChitra', 'Arya', 0),
(5, 3, '12', 'khiyar2', 'Meals', 1, 11, '2023-07-15', 'C:\\\\\\\\Users\\\\\\\\Asus\\\\\\\\Downloads\\\\\\\\specialoffer1.jpg', 'God', 'Arya', 0),
(3, 1, '12', 'khiyar2', 'Meals', 2, 22, '2023-07-15', 'C:\\\\\\\\Users\\\\\\\\Asus\\\\\\\\Downloads\\\\\\\\specialoffer1.jpg', 'God', 'Arya', 0),
(6, 4, '4', 'Pizzamix', 'Fast Food', 2, 22.6, '2023-07-15', 'C:\\\\\\\\Users\\\\\\\\Asus\\\\\\\\Downloads\\\\\\\\images\\\\\\\\pizza4.jpg', 'FarzadChitra', 'Arya', 1);

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
CREATE TABLE IF NOT EXISTS `employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `question` varchar(100) NOT NULL,
  `answer` varchar(100) NOT NULL,
  `date` date DEFAULT NULL,
  `Type` varchar(100) NOT NULL,
  `Balance` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `username`, `password`, `question`, `answer`, `date`, `Type`, `Balance`) VALUES
(1, 'Iman', 'Iman1234', 'What is your favorite Color?', 'Blue', '2023-07-14', 'Restaurant Owner', 0),
(2, 'Arya', 'Arya1234', 'What is your favorite Color?', 'Blue', '2023-07-14', 'Customer', 50),
(3, 'Arya2', 'Arya1234', 'What is your favorite Color?', 'red', '2023-07-14', 'Postman', 6.989999999999998),
(4, 'Arya3', 'Arya1234', 'What is your favorite Color?', 'blue', '2023-07-15', 'Restaurant Owner', 0);

-- --------------------------------------------------------

--
-- Table structure for table `orderdata`
--

DROP TABLE IF EXISTS `orderdata`;
CREATE TABLE IF NOT EXISTS `orderdata` (
  `Location` varchar(1000) NOT NULL,
  `orderdata` varchar(1000) NOT NULL,
  `isdelivered` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `Status` varchar(500) NOT NULL,
  `restaurant` varchar(250) NOT NULL,
  `food` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `postman`
--

DROP TABLE IF EXISTS `postman`;
CREATE TABLE IF NOT EXISTS `postman` (
  `orper` varchar(500) NOT NULL,
  `Src` varchar(500) NOT NULL,
  `dst` varchar(500) NOT NULL,
  `estimatedtime` varchar(500) NOT NULL,
  `Shortestpath` varchar(500) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `postman`
--

INSERT INTO `postman` (`orper`, `Src`, `dst`, `estimatedtime`, `Shortestpath`) VALUES
('Arya', '38', '43', '0:32:32', '[37, 87, 52, 16, 42]'),
('Arya', '1', '37', '0:36:36', '[0, 3, 18, 60, 73, 36]'),
('Arya', '38', '43', '0:32:32', '[37, 87, 52, 16, 42]'),
('Arya', '1', '37', '0:36:36', '[0, 3, 18, 60, 73, 36]');

-- --------------------------------------------------------

--
-- Table structure for table `postman_info`
--

DROP TABLE IF EXISTS `postman_info`;
CREATE TABLE IF NOT EXISTS `postman_info` (
  `Name` varchar(500) NOT NULL,
  `Balance` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
CREATE TABLE IF NOT EXISTS `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `prod_id` varchar(100) NOT NULL,
  `prod_name` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `stock` int(100) NOT NULL,
  `price` double NOT NULL,
  `status` varchar(100) NOT NULL,
  `image` varchar(500) NOT NULL,
  `date` date DEFAULT NULL,
  `Resowner` varchar(500) NOT NULL,
  `Resname` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `prod_id`, `prod_name`, `type`, `stock`, `price`, `status`, `image`, `date`, `Resowner`, `Resname`) VALUES
(1, '1', 'Burger🔥', 'Fast Food', 9, 5.6, 'Available', 'F:\\\\Projects\\\\Intellij IDEA\\\\ProjectGraphic\\\\src\\\\main\\\\resources\\\\com\\\\example\\\\images\\\\burger.jpg', '2023-07-14', 'Iman', 'FarzadChitra'),
(2, '2', 'Pizza', 'Fast Food', 10, 10, 'Available', 'C:\\\\Users\\\\Asus\\\\Downloads\\\\images\\\\pizza.jpg', '2023-07-14', 'Iman', 'FarzadChitra'),
(3, '3', 'Noodels', 'Fast Food', 10, 5, 'Available', 'C:\\\\Users\\\\Asus\\\\Downloads\\\\images\\\\noodles.jpg', '2023-07-14', 'Iman', 'FarzadChitra'),
(4, '4', 'Pizzamix', 'Fast Food', 8, 11.3, 'Available', 'C:\\\\Users\\\\Asus\\\\Downloads\\\\images\\\\pizza4.jpg', '2023-07-14', 'Iman', 'FarzadChitra'),
(5, '5', 'CheeseBurger', 'Fast Food', 10, 8.7, 'Available', 'C:\\\\Users\\\\Asus\\\\Downloads\\\\images\\\\burger1.jpg', '2023-07-14', 'Iman', 'FarzadChitra'),
(6, '6', 'Burgernewstyle', 'Fast Food', 10, 9.3, 'Available', 'C:\\\\Users\\\\Asus\\\\Downloads\\\\images\\\\burger3.jpg', '2023-07-14', 'Iman', 'FarzadChitra'),
(7, '7', 'indian-sweet', 'Meals', 10, 6.5, 'Available', 'C:\\\\Users\\\\Asus\\\\Downloads\\\\images\\\\indian-sweet.jpg', '2023-07-14', 'Iman', 'FarzadChitra'),
(8, '8', 'Naugatmoose', 'Drinks', 7, 3, 'Available', 'C:\\\\Users\\\\Asus\\\\Downloads\\\\images\\\\naugatmoose.jpg', '2023-07-14', 'Iman', 'FarzadChitra'),
(9, '9', 'Waffle', 'Fast Food', 10, 4.1, 'Available', 'C:\\\\Users\\\\Asus\\\\Downloads\\\\images\\\\waffle.jpg', '2023-07-14', 'Iman', 'FarzadChitra'),
(10, '10', 'Donut', 'Meals', 10, 2.1, 'Available', 'C:\\\\Users\\\\Asus\\\\Downloads\\\\images\\\\donut.jpg', '2023-07-14', 'Iman', 'FarzadChitra'),
(11, '11', 'khiyar', 'Meals', 10, 11, 'Available', 'C:\\\\Users\\\\Asus\\\\Downloads\\\\imgbin-cartoon-cucumber-smiling-cucumber-pickle-eLM4vD98s717yfGBqgG3dhYpu.jpg', '2023-07-15', 'Iman', 'Chitra'),
(12, '12', 'khiyar2', 'Meals', 7, 11, 'Available', 'C:\\\\Users\\\\Asus\\\\Downloads\\\\specialoffer1.jpg', '2023-07-15', 'Arya3', 'God'),
(14, '17', 'khiyar', 'Meals', 10, 5, 'Available', 'C:\\\\Users\\\\Asus\\\\Downloads\\\\imgbin-cartoon-cucumber-smiling-cucumber-pickle-eLM4vD98s717yfGBqgG3dhYpu.jpg', '2023-07-15', 'Iman', 'rest');

-- --------------------------------------------------------

--
-- Table structure for table `receipt`
--

DROP TABLE IF EXISTS `receipt`;
CREATE TABLE IF NOT EXISTS `receipt` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(100) NOT NULL,
  `total` double NOT NULL,
  `date` date DEFAULT NULL,
  `em_username` varchar(100) DEFAULT NULL,
  `Resname` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `receipt`
--

INSERT INTO `receipt` (`id`, `customer_id`, `total`, `date`, `em_username`, `Resname`) VALUES
(1, 1, 22, '2023-07-15', 'Arya', 'God'),
(2, 2, 6, '2023-07-15', 'Arya', 'FarzadChitra'),
(3, 3, 11, '2023-07-15', 'Arya', 'God'),
(4, 4, 22.6, '2023-07-15', 'Arya', 'FarzadChitra');

-- --------------------------------------------------------

--
-- Table structure for table `restaurant`
--

DROP TABLE IF EXISTS `restaurant`;
CREATE TABLE IF NOT EXISTS `restaurant` (
  `ResName` varchar(500) NOT NULL,
  `ResOwner` varchar(500) NOT NULL,
  `ResLocation` varchar(500) NOT NULL,
  `ResType` varchar(500) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `restaurant`
--

INSERT INTO `restaurant` (`ResName`, `ResOwner`, `ResLocation`, `ResType`) VALUES
('FarzadChitra', 'Iman', '1', 'FastFood'),
('Chitra', 'Iman', '38', 'Iranian'),
('God', 'Arya3', '38', 'fod'),
('rest', 'Iman', '1', 'fasfood');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
